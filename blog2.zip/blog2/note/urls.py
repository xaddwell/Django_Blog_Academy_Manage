from django.urls import path
from . import views

urlpatterns = [
    path('add', views.add_view),
    path('update', views.update_view),
    path('notelist', views.notelist_view),
    path('delete', views.delete_view),
    # path('<name>',views.get_note_of),
    path('mynote', views.get_note_of, name='mynotes'),
    path('single_note', views.get_note_single),
    path('edit', views.note_edit),
    path("like_handle", views.like_handle),
    path('search', views.search_handle),
    # path('myadd', views.myadd)
]
