from django.db import models
from django.http import HttpResponseRedirect
from django.urls import reverse
# Create your models here.
from user.models import User
from mdeditor.fields import MDTextField


class Note(models.Model):
    title = models.CharField('文章标题', max_length=100)
    tag1 = models.CharField('标签1', max_length=30,)
    tag2 = models.CharField('标签2', max_length=30,)
    comment_num = models.IntegerField("评论数量", default=0)
    seen_num = models.IntegerField("阅读数量", default=0)
    ok_num = models.IntegerField("点赞数量", default=0)
    is_show = models.BooleanField("是否可见", default=True)
    # content = models.TextField("内容")
    content = MDTextField("内容")
    create_time = models.DateTimeField("创建时间", auto_now_add=True)
    update_time = models.DateTimeField("更新时间", auto_now=True)
    auther = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return 'Title %s Auther %s '%(self.title, self.auther)

    def get_absolute_url(self):
        return reverse('mynotes')


class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    note = models.ForeignKey(Note, on_delete=models.CASCADE)

    def __str__(self):
        return "user %s like note %s"%(self.user, self.note)