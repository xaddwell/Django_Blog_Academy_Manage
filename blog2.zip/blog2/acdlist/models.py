from django.db import models

class FollowRelation(models.Model):
    followed = models.CharField(max_length=128, blank=True, null=True)
    following = models.CharField(max_length=128, blank=True, null=True)


