from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse, HttpResponseRedirect, HttpRequest
from django.shortcuts import render
from django.http import JsonResponse
from acdmpage.models import academy_page
from user.models import User
from acdlist.models import FollowRelation
def check_session_cookies(request):
    username=request.session.get('username')
    if not username:
        username=request.COOKIES.get('username')
        if not username:
            return False
        is_exist=User.objects.filter(username=username)
        if is_exist:
            request.session['username']=username
            request.session['uid'] = request.COOKIES.get('uid')
            return True
        else:
            return False
    else:
        is_exist = User.objects.filter(username=username)
        if is_exist:
            return True
        else:
            username = request.COOKIES.get('username')
            if not username:
                return False
            is_exist = User.objects.filter(username=username)
            if is_exist:
                request.session['username'] = username
                request.session['uid'] = request.COOKIES.get('uid')
                return True
            else:
                return False
def check_login(fn):
    def wrap(request, *args,**kwargs):
        if check_session_cookies(request):
            return fn(request, *args, **kwargs)
        else:
            return HttpResponseRedirect('/user/login')
    return wrap
def show_all_follow(request):
    username = request.session.get("username")
    ap = academy_page.objects.all()
    list = []
    for a in ap:
        if FollowRelation.objects.filter(followed=a.user_id, following=username):

            list.append(a)
    return render(request, 'acdlist/acdfollow.html',locals())
def acdlist_view(request):
    username = request.session.get("username")
    ap = academy_page.objects.all()
    dic = {}
    for a in ap:
        if FollowRelation.objects.filter(followed = a.user_id,following = username):

            dic[a] = "取消关注"
        else:
            dic[a] = "关注"
    return render(request, 'acdlist/acdlist.html', locals())
@check_login
def look_view(request):

    def success_response(fans_num, concern):
        data = {}
        data['status'] = 'SUCCESS'
        data['fans_num'] = fans_num
        print(fans_num)
        data['concern'] = concern
        return JsonResponse(data)

    def error_response(message):
        data = {}
        data['status'] = 'ERROR'
        data['message'] = message
        return JsonResponse(data)
    name = request.POST['user']
    flag = request.POST['flag']

    follow_name = request.POST['follow_name']

    user = academy_page.objects.filter(user_id=name)[0]
    follow_record, created = FollowRelation.objects.get_or_create(followed = follow_name,following = name)
    follow_record.save()
    followed_user = academy_page.objects.filter(user_id=follow_name)[0]

    if flag=='1':
        followed_user.fans_num = followed_user.fans_num + 1

    else:
        followed_user.fans_num = followed_user.fans_num - 1
        FollowRelation.objects.filter(followed=follow_name, following=name).delete()
    followed_user.save()
    concern = True
    return success_response(followed_user.fans_num,concern)
