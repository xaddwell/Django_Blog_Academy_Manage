from django.test import TestCase

# Create your tests here.
acd = []
cot = []
re = []
dic = {}
for i in range(10):
    dic['a'] = i
    dic['b'] = i*i
    acd.append(dic)
for j in range(10):
    dic['c'] = j*2
    dic['d'] = j*3
    cot.append(dic)
for i in range(len(acd)):
    #dic = dict(acd[i].items()+cot[i].items())
    acd[i].update(cot[i])
    re.append(acd[i])
print(re)
for i in re:
    print(i['c'])
    print(i['a'])
