from django.urls import path
from . import views

urlpatterns = [
path('acdlist', views.acdlist_view),
path('look_button',views.look_view),
path('my_concern',views.show_all_follow)
]