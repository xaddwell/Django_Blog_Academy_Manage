from django.apps import AppConfig


class AcdlistConfig(AppConfig):
    name = 'acdlist'
