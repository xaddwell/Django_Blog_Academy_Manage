from django.http import HttpResponse
from django.shortcuts import render
from statistic.views import add_visit,get_ip_address_info,get_client_ip
from statistic.models import IpCoordinate

@add_visit
def index_view(request):
    username=str(request.session.get('username'))
    visit_num=IpCoordinate.objects.all().count()
    ip_str = get_client_ip(request)
    if ip_str == "127.0.0.1":
        ip_str = '183.94.105.244'
    ip_info = get_ip_address_info(ip_str)
    if ip_info["code"] != 0:
        city = ""
        province = "中国"
    else:
        city = ip_info["city"]
        province = ip_info["province"]

    return render(request,'index/index.html',locals())

def index_test(request):
    username=str(request.session.get('username'))
    return render(request,'index/test.html',locals())