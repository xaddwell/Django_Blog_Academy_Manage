from django.db import models
from user.models import User
# Create your models here.

class award(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    time=models.CharField("获奖日期", max_length=100)
    title = models.CharField("奖项title", max_length=100)
    description = models.TextField("获奖描述")
    link = models.CharField("相关链接", max_length=300)
    auther_list = models.CharField("作者列表", max_length=100)

class project(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    time = models.CharField("项目日期", max_length=100)
    title = models.CharField("标题", max_length=100)
    description = models.TextField("项目描述")
    link = models.CharField("项目链接", max_length=300)
    auther_list = models.CharField("作者列表", max_length=100)

class paper(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    time = models.CharField("发表时间",max_length=100)
    title=models.CharField("论文标题",max_length=100)
    description=models.TextField("论文描述")
    link=models.CharField("论文链接",max_length=300)
    auther_list=models.CharField("作者列表",max_length=100)

class record(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    time = models.CharField("记录时间", max_length=100)
    title = models.CharField("日志标题", max_length=100)
    description = models.TextField("内容")

class service(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    time = models.CharField("服务时间",max_length=100)
    title=models.CharField("标题",max_length=100)
    description=models.TextField("服务描述")
    link=models.CharField("文章链接",max_length=300)

class intro(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    description=models.TextField("服务描述")

class academy_page(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    introduction=models.TextField("自我介绍")

    intro_num=models.IntegerField("intro_num",default=0)
    paper_num = models.IntegerField("paper_num", default=0)
    project_num = models.IntegerField("project_num", default=0)
    record_num = models.IntegerField("record_num", default=0)
    service_num = models.IntegerField("service_num", default=0)
    award_num = models.IntegerField("award_num", default=0)
    fans_num = models.IntegerField("fans_num", default=0)
    phone_link = models.CharField("电话号码", max_length=300, default="#")
    email_link = models.CharField("邮箱地址", max_length=300, default="#")
    github_link = models.CharField("github地址", max_length=300, default="#")
    zhihu_link = models.CharField("知乎地址", max_length=300, default="#")
    blog_link = models.CharField("博客地址", max_length=300, default="#")

    name=models.CharField("主页名字",max_length=100)
    major=models.CharField("专业",max_length=100)
    create_time=models.DateTimeField("创建时间",auto_now=True)
    update_time=models.DateTimeField("更新时间",auto_now_add=True)
    pic=models.ImageField("上传的图片",upload_to='image',default='/static/images/bk.jpg')
    fans_num = models.IntegerField("fans_num", default=0)
    # award

