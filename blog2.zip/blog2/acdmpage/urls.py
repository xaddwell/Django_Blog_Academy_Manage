from django.urls import path
from . import views as acdmpage_views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns=[
    path('mysite',acdmpage_views.acdmpage_view),
    path('test',acdmpage_views.test_view),
    path('<search_name>', acdmpage_views.ones_view),
]
urlpatterns += staticfiles_urlpatterns()