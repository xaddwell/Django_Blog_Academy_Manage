from django.db import models
# Create your models here.
class User(models.Model):
    username=models.CharField("用户名",max_length=30,unique=True,primary_key=True)
    password=models.CharField("密码",max_length=32)
    blog_num=models.IntegerField("博客数量",default=0)
    mail_address=models.CharField("邮箱地址",max_length=20)
    user_level=models.IntegerField("用户等级",default=0)
    create_time=models.DateTimeField("创建时间",auto_now_add=True)
    update_time = models.DateTimeField("更新时间", auto_now=True)

    def __str__(self):
        return 'username %s'%(self.username)
